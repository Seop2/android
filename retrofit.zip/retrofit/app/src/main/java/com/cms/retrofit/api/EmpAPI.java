package com.cms.retrofit.api;

import com.cms.retrofit.vo.EmpVO;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.GET;

//참고 문서 https://square.github.io/retrofit/
public interface EmpAPI {
    @GET("/api/v1/emp")
    Call<List<EmpVO>> listEmp();
}
