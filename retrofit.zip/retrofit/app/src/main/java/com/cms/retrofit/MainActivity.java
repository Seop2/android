package com.cms.retrofit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.cms.retrofit.api.EmpAPI;
import com.cms.retrofit.vo.EmpVO;

import java.util.List;
import java.util.Map;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private String BASE_URL = "http://192.168.0.20:8080";
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(BASE_URL)
                .build();
        EmpAPI api = retrofit.create(EmpAPI.class);
        Call<List<EmpVO>> call = api.listEmp();

        call.enqueue(new Callback<List<EmpVO>>(){
            //통신(API) 성공
            @Override
            public void onResponse(Call<List<EmpVO>> call, Response<List<EmpVO>> response) {
                textView = (TextView) findViewById(R.id.main_text);
                List<EmpVO> list = response.body();
                String text = "";
                for(EmpVO vo : list){
                    text += "[ "+vo.getEname()+", "+vo.getJob()+" ]";
                }
                textView.setText(text);
            }
            //통신(API) 실패
            @Override
            public void onFailure(Call<List<EmpVO>> call, Throwable t) {
                System.out.println("===========");
                t.printStackTrace();
                System.out.println("===========");
            }
        });

        setContentView(R.layout.activity_main);
    }
}