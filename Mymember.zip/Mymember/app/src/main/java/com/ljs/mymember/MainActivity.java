package com.ljs.mymember;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.ljs.mymember.api.EmpAPI;
import com.ljs.mymember.vo.Empvo;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private String BASE_URL = "http://192.168.0.74:8080";
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Retrofit ret = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(BASE_URL)//api 주소 입력
                .build();//레트로핏 빌드 시작!

        EmpAPI api = ret.create(EmpAPI.class);//1. 생성한 api 레트로핏에  생성
        Call<List<Empvo>>call = api.callEmpAll();//2.해당 api호출
        call.enqueue(new Callback<List<Empvo>>() {//3.요청된 데이터 확인
            //onResponse: api통신 완료(ajax == success)
            @Override
            public void onResponse(Call<List<Empvo>> call, Response<List<Empvo>> response) {
                textView = (TextView)findViewById(R.id.empText);
                List<Empvo>list = response.body();//데이터 불러옴
                String text = "";
                for(Empvo vo :list)
                {
                    text += "["+vo.getEmpno()+","+vo.getEname()+","+vo.getJob()+"]";
                }
                textView.setText(text);
            }

            @Override
            public void onFailure(Call<List<Empvo>> call, Throwable t) {
                System.out.println("==========");
                t.printStackTrace();;//에러확인
                System.out.println("==========");
            }
        });
    }
}