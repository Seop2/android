package com.ljs.mymember.api;

import com.ljs.mymember.vo.Empvo;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface EmpAPI {
    @GET("/api/v1/emp")
    Call<List<Empvo>>callEmpAll();
}
